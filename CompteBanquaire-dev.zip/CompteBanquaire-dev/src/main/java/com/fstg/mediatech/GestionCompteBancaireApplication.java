package com.fstg.mediatech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionCompteBancaireApplication {


    public static void main(String[] args) {
        SpringApplication.run(GestionCompteBancaireApplication.class, args);


    }

}
